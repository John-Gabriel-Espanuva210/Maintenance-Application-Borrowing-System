-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 05, 2024 at 01:43 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mabs`
--

-- --------------------------------------------------------

--
-- Table structure for table `boroweditem`
--

CREATE TABLE `boroweditem` (
  `borrowed_id` int(11) NOT NULL,
  `student_name` varchar(30) NOT NULL,
  `id_number` varchar(10) NOT NULL,
  `cell_number` varchar(15) NOT NULL,
  `course` varchar(12) NOT NULL,
  `year_level` varchar(20) NOT NULL,
  `section` varchar(20) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `approvedBy` varchar(30) NOT NULL,
  `borrow_date` date NOT NULL,
  `due_date` date NOT NULL,
  `item_name` varchar(30) NOT NULL,
  `good_item` int(11) NOT NULL,
  `bad_item` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `boroweditem`
--

INSERT INTO `boroweditem` (`borrowed_id`, `student_name`, `id_number`, `cell_number`, `course`, `year_level`, `section`, `purpose`, `approvedBy`, `borrow_date`, `due_date`, `item_name`, `good_item`, `bad_item`) VALUES
(19, 'Gildark', '2020-2717', '0912049', 'BS-Indtech', '2nd Year', 'Faithful', 'Cleaning', 'Dionic', '2023-12-28', '2023-12-29', 'Broom', 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `history_id` int(11) NOT NULL,
  `borrowed_id` int(11) NOT NULL,
  `student_name` varchar(30) NOT NULL,
  `id_number` varchar(10) NOT NULL,
  `cell_number` varchar(15) NOT NULL,
  `course` varchar(30) NOT NULL,
  `year_level` varchar(10) NOT NULL,
  `section` varchar(30) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `approvedBy` varchar(30) NOT NULL,
  `borrow_date` date NOT NULL,
  `due_date` date NOT NULL,
  `item_name` varchar(30) NOT NULL,
  `good_item` int(11) NOT NULL,
  `bad_item` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`history_id`, `borrowed_id`, `student_name`, `id_number`, `cell_number`, `course`, `year_level`, `section`, `purpose`, `approvedBy`, `borrow_date`, `due_date`, `item_name`, `good_item`, `bad_item`) VALUES
(1, 4, 'Jeffrey Tuason', '2020-1387', '09456424506', 'BS-Indtech', 'BS-Indtech', 'Faithful', 'CSS NCII', 'John Gabriel Espanueva', '2023-12-19', '2023-12-19', 'Duck Tape', 3, 0),
(2, 7, 'John Gabriel Espanueva', '2020-1410', '09129077613', 'BS-Indtech', 'BS-Indtech', 'Faithful', 'program', 'Dionic', '2023-12-21', '2023-12-22', 'Chairs', 10, 0),
(3, 8, 'Gabby', '2020-1411', '029121', 'BS-Indtech', 'BS-Indtech', 'Faithful', 'Panel', 'Cupal', '2023-12-21', '2023-12-21', 'Tables', 3, 0),
(4, 9, 'Gabby', '2020-1411', '029121', 'BS-Indtech', 'BS-Indtech', 'Faithful', 'Panel', 'Cupal', '2023-12-21', '2023-12-21', 'Chairs', 48, 0),
(5, 10, 'Richar C. Cupal', '1', '097778888', 'BS-Indtech', 'BS-Indtech', 'Faithful', 'Panel', 'Dionic', '2023-12-21', '2023-12-22', 'Chairs', 0, 0),
(6, 6, 'Jeffrey', '2020-1387', '09456424506', 'BS-Indtech', 'BS-Indtech', 'Faithful', 'CSS NCII', 'John Gabriel Espanueva', '2023-12-20', '2023-12-21', 'Duck Tape', 1, 0),
(7, 18, 'Gabs', '2020-1217', '0912950', 'BS-Indtech', '3rd Year', 'Faithful', 'Classes', 'Dionic', '2023-12-27', '2023-12-28', 'Chairs', 1, 0),
(8, 17, 'Jushua', '2020-1927', '0909090', 'BS-Indtech', 'BS-Indtech', 'Grateful', 'Classes', 'Dionic', '2023-12-27', '2023-12-28', 'Chairs', 2, 0),
(9, 16, 'Ritchi Gumera', '2020-2000', '09210219', 'BS-Indtech', 'BS-Indtech', 'Faithul', 'Christmas Decors', 'Dionic', '2023-12-21', '2023-12-22', 'Ladders', 2, 0),
(10, 15, 'Christian Restauro', '2020-1999', '0921210', 'BS-Indtech', 'BS-Indtech', 'Faithful', 'Cleaning', 'Dionic', '2023-12-21', '2023-12-22', 'Broom', 3, 0),
(11, 14, 'Carl Michael', '0919', '098765', 'BS-Indtech', 'BS-Indtech', 'Faithful', 'PC build', 'Dionic', '2023-12-21', '2023-12-22', 'Screw Driver', 1, 1),
(12, 13, 'Mark Joshua Cagang', '1220', '091019', 'BS-Indtech', 'BS-Indtech', 'Faithful', 'PC servicing', 'Dionic', '2023-12-21', '2023-12-25', 'Dust Pan', 3, 0),
(13, 12, 'Kadusale', '1212', '0101010', 'BS-Indtech', 'BS-Indtech', 'Faithful', 'Panel', 'Soque', '2023-12-21', '2023-12-22', 'Chairs', 4, 0),
(14, 11, 'Richard', '11', '09888', 'BS-Indtech', 'BS-Indtech', 'Grateful', 'Panel', 'Dionic', '2023-12-21', '2023-12-22', 'Chairs', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `item_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `good_item` int(11) NOT NULL,
  `bad_item` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `location` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`item_id`, `name`, `good_item`, `bad_item`, `category`, `location`) VALUES
(2, 'Dust Pan', 3, 3, 'Furniture', 'Stock Room'),
(4, 'Screw Driver', 3, 1, 'Hand Tools', 'Maintainance'),
(5, 'Duck Tape', 12, 0, 'Electric Hardware', 'Maintainance'),
(7, 'Chairs', 250, 7, 'Furniture', 'Complex'),
(8, 'Tables', 25, 0, 'Furniture', 'Student Lounge'),
(10, 'Ladders', 3, 0, 'Furniture', 'New building'),
(11, 'Broom', 5, 0, 'Furniture', 'Maintenance office');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `boroweditem`
--
ALTER TABLE `boroweditem`
  ADD PRIMARY KEY (`borrowed_id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`history_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`item_id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `boroweditem`
--
ALTER TABLE `boroweditem`
  MODIFY `borrowed_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
